# FoodWise Pro v36 — Spoiled Food Recycling / Composting Fix

## Problem
FoodWise AI previously interpreted questions such as "Mere tamatar kharab ho gaye, recycle kaise karu?" as inventory/expiry or waste-log questions, rather than explaining composting. When the Gemini key was absent or the Gemini request failed, the local assistant could not give food-recycling instructions.

## Fix
- Added `spoiledFoodRecyclingReply()` to `server.js`, checked before all other inventory, waste, shopping and recipe intent rules in **both** local and Gemini chat handlers.
- Responds to Hindi (Devanagari), Hinglish, or English recycling / compost / spoiled-food questions, even when Gemini is not connected.
- Gives actionable guidance for spoiled fruit/vegetables, dairy, meat/fish/eggs, cooked foods, and used cooking oil. Asks for the food type when unknown.
- Warns against eating spoiled food, adding animal products or oily cooked food to ordinary open compost, and dumping oil down drains. Municipal organic collection is recommended **only where that service accepts the specific food**.
- Added a quick question chip in AI Assistant: "♻️ Spoiled food recycling".
- Updated app / Service Worker cache revision to v36 so the chip loads after deployment.
- Unrelated app screens, user data, login/signup behavior and 30-reply chat retention are unchanged.

## Test
1. Open AI Assistant, click **♻️ Spoiled food recycling**, or ask:
   - `Mere tamatar kharab ho gaye, compost kaise karu?`
   - `Mera food kharab ho gaya hai, ise recycle kaise karun?`
   - `Spoiled milk kaise dispose karu?`
   - `Can I compost spoiled chicken?`
   - `मेरा खाना खराब हो गया है, खाद कैसे बनाऊँ?`
2. Read food-specific instructions. Confirm non-spoilage questions like `Mere paas kitne fruit hain?` still use inventory Q&A.
3. Works with or without `GEMINI_API_KEY`. To deploy an online copy, deploy this ZIP's contents and let the host restart the server.

**Safety:** Composting rules vary by local municipality and equipment. The assistant offers general guidance rather than confirming specific municipal pickup services.
