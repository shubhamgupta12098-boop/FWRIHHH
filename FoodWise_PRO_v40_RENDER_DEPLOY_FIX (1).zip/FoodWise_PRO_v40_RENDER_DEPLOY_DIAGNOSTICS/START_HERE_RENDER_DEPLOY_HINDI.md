# FoodWise Pro v40 - GitHub / Render fix

## Root cause identified
GitHub `main` was still serving v32 `package.json` and `public/index.html` linking `style.css?v=33`, while your uploaded ZIP contains v39. A successful `git push` may push only previously COMMITTED files; unsaved/unstaged changes (VS Code "M") do not go to GitHub automatically.

## Windows / VS Code
1. Backup the current `USER WEB` folder.
2. Extract this ZIP. Open the inner `FoodWise_PRO_v40_RENDER_DEPLOY_DIAGNOSTICS` folder.
3. Copy its CONTENTS (`server.js`, `package.json`, `render.yaml`, `public` folder, etc.) into your EXISTING Git repository folder (`USER WEB`) and replace existing files. DO NOT put the extracted outer folder inside `USER WEB`.
4. Keep your existing local `.env` private. This ZIP excludes it and excludes local account/session data.
5. Save files; open VS Code terminal in `USER WEB` and run:

   git status
   git add .
   git diff --cached --stat
   git diff --cached --name-only
   git commit -m "FoodWise Pro v40 Render deployment fix"
   git push origin main

If `git commit` says nothing to commit, the files were likely not copied into the correct Git folder. Use `git status` and `git rev-parse --show-toplevel`.

SECURITY: Check `git diff --cached --name-only` before commit. If `.env` or `data/local-auth.json`, `data/local-state.json` or `data/local-session-secret.txt` is listed, STOP. Do not publish secrets.

## Confirm GitHub has new code before deploying
Open https://github.com/shubhamgupta12098-boop/FWRIHHH/blob/main/package.json
It MUST contain `"version": "40.0.0"`.
Open https://github.com/shubhamgupta12098-boop/FWRIHHH/blob/main/public/index.html
It MUST contain `style.css?v=40` and `app.js?v=40`.

## Render dashboard
Service: https://dashboard.render.com/
Settings: Branch = main; Root Directory = blank (repo root); Build = npm install; Start = npm start.
Environment: NODE_ENV=production; LOCAL_MODE=false; MONGODB_URI configured; FIREBASE_API_KEY configured; SESSION_SECRET configured. Optional: GEMINI_API_KEY for full Gemini chat, CLOUDFLARE_ACCOUNT_ID + CLOUDFLARE_API_TOKEN for AI images, web push subscriptions require supported browser/permission and push configuration. Never send any secret keys in screenshots.
Deploy: Manual Deploy -> Deploy latest commit (if Auto Deploy is not enabled). Check Deploy Events/Logs.

## Check production
1. https://food-west-reduction-in-household.onrender.com/api/version
   Expected: `"version":"40.0.0"`, `"assets":"40"`, `"mode":"cloud"`. `aiConfigured:false` means Gemini API key not configured; food advice may still use offline rules.
2. https://food-west-reduction-in-household.onrender.com/api/health
   Expected: `"ok":true`, `"mongo":"connected"`, `"mode":"cloud"`.
3. Reload website using Ctrl+Shift+R. If installed as PWA, close it and reopen; if still old, clear only this site's stored/cache data (note this may sign you out) and reinstall.
4. On mobile browser, OS native push notifications still depend on permission, HTTPS, browser compatibility and background push subscription, not responsive CSS.

## If still not working
Send: the output of /api/version and /api/health (no passwords/tokens) + Render's last deploy STATUS and first relevant ERROR LOG lines. Do not send `.env`, MongoDB URI, API keys, Firebase credentials or session secrets.
