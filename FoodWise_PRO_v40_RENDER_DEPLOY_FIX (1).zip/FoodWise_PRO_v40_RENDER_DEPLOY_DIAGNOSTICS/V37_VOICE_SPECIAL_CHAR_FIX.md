# FoodWise Pro v37 — Voice Special Character Fix

## Fix
- AI voice and inventory voice use one centralized browser speech function.
- Speech-only cleanup strips Markdown (e.g. `**`, `#`, backticks), emojis, symbols (`*`, `#`, `@`, `_`, `+`, `=`), raw URLs and email addresses before sending words to SpeechSynthesis.
- Food quantities and values remain understandable (`₹200` becomes `rupees 200`, `50%` becomes `50 percent`).
- Hindi, Hinglish and English spoken content remains supported.
- Original AI replies on screen and in chat history are untouched. Only the spoken text is cleaned.
- Blank/symbol-only answers are not spoken, and voice inventory onDone still executes to resume listening.
- v36 composting/recycling guidance and all other features are retained.

## Test
- Use Voice Q&A and ask: `Mere tamatar kharab ho gaye, compost kaise karu?`
- Verify visually the AI answer is unchanged, while voice does not announce star, hash, at-symbol, underscore, emoji or other markup.
- Try speech for `**Tip:** ₹200, 50% waste — use 2–3 tomatoes.`; it should say normal words and numbers without reading punctuation names.
- Voice inventory should still speak prompts, hear answers, and save items.

## Deploy
Deploy these v37 files to replace v36. Browser assets and service worker cache are versioned `v37`. If the old site is cached, refresh the page after deploying.
