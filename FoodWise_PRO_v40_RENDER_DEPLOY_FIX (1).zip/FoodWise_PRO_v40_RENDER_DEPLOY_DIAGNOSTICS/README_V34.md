# FoodWise Pro v34 — Chat Auto-Reset + Create Account Fix

## Start
1. Run `npm install` in this directory.
2. Run `npm start`.
3. Visit `http://localhost:3000`.
4. Click **Create Account** on the login screen to register. Password must have 10+ characters, with at least one letter and one digit.

## AI Chat
After every 30 completed **AI answers** the server clears the user's chat messages from the database and the app automatically opens a fresh AI chat page. The same cleanup applies in MongoDB Atlas when in Cloud Mode, and `data/local-state.json` when in Local Mode. Inventory, household, and other state are preserved. A pending/failed reply does not count. Existing histories with 30+ answers are cleared on the next state load.

In Cloud Mode, set `LOCAL_MODE=false`, `MONGODB_URI`, and `FIREBASE_API_KEY` in your deployment environment. See `RENDER_DEPLOYMENT.md`. Editing this ZIP does not modify a live deployment: deploy the new code to enable clearing on the real database.

See `V34_CHAT_EXPIRY_SIGNUP_FIX.md` for technical details.
