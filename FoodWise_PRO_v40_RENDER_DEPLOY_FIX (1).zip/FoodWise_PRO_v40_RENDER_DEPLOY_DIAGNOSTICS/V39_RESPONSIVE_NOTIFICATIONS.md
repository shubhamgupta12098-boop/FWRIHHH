# FoodWise Pro v39 — Responsive Notifications

This project is **vanilla JavaScript + HTML + CSS + a Node.js backend**; it does not use React. The requested notification responsiveness was implemented directly without changing the framework or existing logic.

## Changes
- Notification settings card, expiry/leftover/daily reminder cards and action buttons adapt automatically to narrow screens (including ~320px) through fluid sizing and a breakpoint.
- Long names, translated text, status descriptions and buttons wrap instead of clipping or overflowing.
- In-app alerts use viewport-safe dimensions, a close button, longer readable duration and safe-area-aware placement. Normal toasts also have responsive dimensions and readable duration.
- Existing browser/OS push notification logic remains unchanged; **native notification banners are sized by Android/iOS/browser, not the website**.
- Cache and asset version bumped to v39 so an old service worker is less likely to serve stale CSS/JS after deployment.

## Deployment
Deploy the full v39 folder and refresh/reopen installed PWA once to pick up the updated cache. On mobile use Notifications -> Test in-app / Test notification. Grant permissions if needed.

## Testing
JavaScript syntax, HTML/CSS structure and viewport browser render checks (320px, 375px, 430px, 480px, 768px) are performed separately during packaging; native Android/iOS lock-screen styling still requires a real device.
