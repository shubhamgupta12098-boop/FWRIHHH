# FoodWise Pro v34 — 30-reply chat reset + signup fix

- Each completed AI assistant answer counts as one reply; after the 30th answer the Node.js server clears `data.chatHistory` in MongoDB `states` (or local `data/local-state.json`) BEFORE returning success. The 30th answer is displayed briefly, then the page automatically navigates to a fresh AI Assistant view.
- The response includes `chatReset`, `repliesUsed`, `chatReplyLimit`, and the server-owned `chatHistory`. Failed requests do not count.
- The chat history is not mirrored into localStorage. Normal state saves cannot restore deleted chat history, even if delayed. Prior chats with at least 30 replies are cleared by state migration.
- No other household data is deleted. No separate chat collection exists.
- Login-page Create Account tabs use explicit button type and click handling. Fixed the signup password `pattern` to permit any 10+ character password containing a letter and a digit (previously required the letter `d` because of JS string escaping).
- Service worker cache and asset versions bumped to v34.

## Deployment

Use `npm install` then `npm start`. On Render, deploy this ZIP's source. MongoDB deletion happens on the connected deployment's configured MONGODB_URI; no production database is modified by editing the ZIP.
