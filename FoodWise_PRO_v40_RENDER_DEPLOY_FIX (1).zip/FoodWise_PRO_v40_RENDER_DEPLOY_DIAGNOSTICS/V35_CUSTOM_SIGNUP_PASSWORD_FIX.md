# FoodWise Pro v35 — Custom Create Account Password

- Signup now accepts **any password with at least 6 characters** (numbers only, letters only, symbols, or combinations). No uppercase, letter/number combination, or 10-character restriction. Firebase Email/Password sets the 6-character minimum, so shorter passwords are not supported by the cloud authentication provider.
- Both Local Mode and Cloud Mode validate the same minimum on the server; the signup input uses `minlength="6"` without a restrictive `pattern`.
- The Change Password form and its server route use the same policy, to avoid a mismatch after signup. Login works with existing passwords unchanged.
- Friendly weak-password errors updated. No plaintext passwords are stored by this change; local credentials remain PBKDF2-hashed, cloud credentials remain with Firebase Authentication.
- v34 AI Assistant 30-reply reset and MongoDB chatHistory deletion remain unchanged.
- Cache revision v35 lets browsers load the updated signup form after deployment.

## Deploy

Deploy this project's updated code to Render (or restart your local Node server). The live site's behavior does not change until the new code is deployed.
