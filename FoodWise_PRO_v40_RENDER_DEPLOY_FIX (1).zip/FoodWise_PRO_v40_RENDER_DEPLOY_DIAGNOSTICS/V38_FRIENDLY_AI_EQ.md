# FoodWise Pro v38 — Friendly AI / Conversational EQ

## Changes
- More thoughtful Gemini prompt: responsive, concise Hindi/Hinglish/English, and situational empathy rather than repetitive cheerleading.
- Offline friendly conversational responses to greetings, thanks, compliments, and emotions around wasted food, even without an AI key.
- Local app-data responses retain exact values; a few budget/expiry replies gain a short friendly introduction.
- Spoiled-food/composting instructions now have a warmer opening while retaining all safety instructions.
- English app settings do not force an explicitly Hinglish/Hindi question to receive an English reply.
- Normal offline answers do not display a false Gemini-error warning. Genuine Gemini failure warnings remain visible.
- Voice speaking rate slightly relaxed and voice special-character cleanup remains intact.
- App welcome message is friendlier. Cache and version updated to v38.

## Quick manual checks
- Ask `Hi`, `Kaise ho?`, and `Shukriya` offline; expect a warm short answer.
- Ask `Mera khana waste ho gaya, bura lag raha hai` offline; expect a non-judgmental practical response.
- Ask `Mere tamatar kharab ho gaye, compost kaise karu?`; expect full safe compost steps.
- Ask `Mera budget kitna bacha hai?`; expect recorded budget numbers unchanged.
- Ask `Mere paas kitne fruit hain?`; expect inventory-derived answer.
- Voice: special characters are not read aloud.
- Connected Gemini: live endpoint must be verified with a valid API key; prompt behavior was updated but external AI output depends on the model.

## Deploy
Deploy v38 server and public files together, then refresh browser / installed PWA to update cache.
